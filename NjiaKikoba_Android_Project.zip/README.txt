NJIAKIKOBA Android APK project
Website: https://njiakikobapro.onrender.com/

Build:
1. Open this folder in Android Studio.
2. Wait for Gradle sync.
3. Build > Build APK(s).
4. APK will be in app/build/outputs/apk/debug/
